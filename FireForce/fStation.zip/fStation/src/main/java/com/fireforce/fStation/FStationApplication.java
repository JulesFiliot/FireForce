package com.fireforce.fStation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FStationApplication {

	public static void main(String[] args) {
		SpringApplication.run(FStationApplication.class, args);
	}

}
